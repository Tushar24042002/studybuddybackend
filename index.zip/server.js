import express  from "express";
import mysql from "mysql";
import cors from 'cors';
// import upload from 'express-fileupload';
// const upload = require('express-fileupload');
import session from 'express-session';
import jwt from'jsonwebtoken';
import multer from "multer";
import path from "path";
import { unlink } from 'node:fs';
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended : false}));
// var auth = false;
// const authFunction=(auth)=>{
//     auth = true;
// }
const storage = multer.diskStorage({
    destination : (req,res,cb)=>{
        cb(null,'../public/assets/images/ncertBooks')
    },
    filename :(req,file,cb)=>{
        cb(null, file.fieldname + "" + Date.now() + path.extname(file.originalname));
    }
})

const upload = multer({
    storage :storage
})


const syllabuSstorage = multer.diskStorage({
    destination : (req,res,cb)=>{
        cb(null,'../public/assets/images/ncertSyllabus')
    },
    filename :(req,file,cb)=>{
        cb(null, file.fieldname + "" + Date.now() + path.extname(file.originalname));
    }
})

const uploadSyllabus = multer({
    storage :syllabuSstorage
})

// const db = mysql.createConnection({
//     host :"localhost",
//     user:"vhfaxmrm_admin",
//     password:"P-fc)8xS%iBp",
//     database:"vhfaxmrm_studybuddy"
// })



const db = mysql.createConnection({
    host :"localhost",
    user:"root",
    password:"",
    database:"studybuddy"
})
// app.get('/', function(req, res){
//     res.sendfile('index.ejs');
// });

app.get("/",(req,res)=>{
    const sql = "SELECT * FROM `admin`";
    // res.sendFile(__dirname +"/books");
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        // res.sendFile("books");
        return res.json(result);
    })
})



// login url
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (username && password) {
      db.query(
        'SELECT * FROM admin WHERE username = ? AND password = ?',
        [username, password],
        (err, results) => {
          if (err) {
            throw err;
          }
          if (results.length > 0) {
            const user = results[0];
            const token = jwt.sign({ id: user.id, username: user.username }, 'your_secret_key');
            res.json({ Login : true, token , results});
          } else {
            res.status(401).json({ error: 'Invalid username or password' });
          }
        }
      );
    } else {
      res.status(400).json({ error: 'Please enter username and password' });
    }
  });
  


  app.get('/backendArea', (req, res) => {
    const token = req.headers.authorization;
    if (token) {
      jwt.verify(token, 'your_secret_key', (err, decoded) => {
        if (err) {
          res.status(401).json({ error: 'Invalid token' });
        } else {
          res.json({ message: `Welcome back, ${decoded.username}!` });
        }
      });
    } else {
      res.status(401).json({ error: 'Token not provided' });
    }
  });



  app.get('/home', (req, res) => {
    const token = req.headers.authorization;
    if (token) {
      jwt.verify(token, 'your_secret_key', (err, decoded) => {
        if (err) {
          res.status(401).json({ error: 'Invalid token' });
        } else {
          res.json({ message: `Welcome back, ${decoded.username}!` });
        }
      });
    } else {
      res.status(401).json({ error: 'Token not provided' });
    }
  });


app.get("/books",(req,res)=>{

    const sql = "SELECT * FROM `books`";
    // res.sendFile(__dirname +"/books");
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        // res.sendFile("books");
        return res.json(result);
    })
})



app.get("/backendSyllabusView",(req,res)=>{

    const sql = "SELECT * FROM `syllabus`";
    // res.sendFile(__dirname +"/books");
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        // res.sendFile("books");
        return res.json(result);
    })
})






app.get("/edit-books/:id&:files", (req,res)=>{
    const {id,files} = req.params;
    const sql = "SELECT * FROM `books` WHERE id = ? ";
    // res.sendFile(__dirname +"/books");
    db.query(sql,[id],function(error, result){
        if(error) throw error;
        console.log(result);
        // res.render(__dirname + "/edit", {labs:result});
        return res.json(result);
    })
})



app.post('/edit-books/:id&:files', upload.single("image"), function(req, res, next) {
    var id= req.params.id;
    var files= req.params.files;
  console.log(req.file);
    if(req.file){
      var updateData = {
        bookname : req.body.bookname,
        booktitle : req.body.booktitle,
        class : req.body.class,
        pdffile : req.file.filename,
        subject : req.body.subject,
        description : req.body.description,
      }
      unlink(`../public/assets/images/ncertBooks/${files}`, (err) => {
          if (err) throw err;
          console.log('path/file.txt was deleted');
        });
     }
    else{
        var updateData = {
            bookname : req.body.bookname,
            booktitle : req.body.booktitle,
            class : req.body.class,
            subject : req.body.subject,
            description : req.body.description,
          }
    }
      // var updateData=req.body;
      console.log(req.file + ""+updateData);
        var sql = `UPDATE books SET ? WHERE id= ?`;
        db.query(sql, [updateData, id], function (err, data) {
        if (err) throw err;
        console.log(data.affectedRows + " record(s) updated");
        res.redirect('/books');
      });
  
     
    // res.redirect('/data');
  });




app.delete("/books/delete/:id&:files",(req,res)=>{
    const {id,files} = req.params;
    unlink(`../public/assets/images/ncertBooks/${files}`, (err) => {
        if (err) throw err;
        console.log('path/file.txt was deleted');
      });
    const sqlRemove = "DELETE FROM `books` WHERE id = ?";
    db.query(sqlRemove,id,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        return res.json(result);
    })
})


app.get("/books6",(req,res)=>{

    const sql = "SELECT * FROM `books` WHERE Class=6";
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        return res.json(result);
    })
})


app.get("/scienceBooks6",(req,res)=>{
    const {subject} = "Science";
    const sql = "SELECT * FROM `books` WHERE Class=6 AND Subject=Science";
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        return res.json(result);
    })
})






app.get("/books7",(req,res)=>{
    const sql = "SELECT * FROM `books` WHERE Class=7";
    // res.sendFile(__dirname +"/books");
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        // res.sendFile("books");
        return res.json(result);
    })
})




app.get("/books12",(req,res)=>{
    const sql = "SELECT * FROM `books` WHERE Class=12";
    // res.sendFile(__dirname +"/books");
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        // res.sendFile("books");
        return res.json(result);
    })
})




app.get("/books11",(req,res)=>{
    const sql = "SELECT * FROM `books` WHERE Class=11";
    // res.sendFile(__dirname +"/books");
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        // res.sendFile("books");
        return res.json(result);
    })
})



app.get("/books10",(req,res)=>{
    const sql = "SELECT * FROM `books` WHERE Class=10";
    // res.sendFile(__dirname +"/books");
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        // res.sendFile("books");
        return res.json(result);
    })
})




app.get("/books9",(req,res)=>{
    const sql = "SELECT * FROM `books` WHERE Class=9";
    // res.sendFile(__dirname +"/books");
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        // res.sendFile("books");
        return res.json(result);
    })
})



app.get("/books8",(req,res)=>{
    const sql = "SELECT * FROM `books` WHERE Class=8";
    // res.sendFile(__dirname +"/books");
    db.query(sql,(err,result)=>{
        if(err) return res.json({Message : "Error in connecting database"});
        // res.sendFile("books");
        return res.json(result);
    })
})




app.post("/books", upload.single("image") ,(req,res)=>{
    const sql ="INSERT INTO `books`( `bookname`, `booktitle`, `class`, `subject`, `pdffile`, `description`) VALUES(?)";
    console.log(req.body);
    console.log(req.file);
    const values =[
        req.body.bookname,
        req.body.booktitle,
        req.body.class,
        req.body.subject,
        req.file.filename,
        req.body.description       
    ];
    // const image = ;
    db.query(sql,[values],(err,result)=>{
        // if(req.files.uploadfilefile){
            console.log(req.file, req.body)
        // }
        if(err) return res.json(err);
        return res.json(result);   
    })
})


app.post("/createSyllabus", uploadSyllabus.single("image") ,(req,res)=>{
    const sql ="INSERT INTO `syllabus`( `bookname`, `booktitle`, `class`, `subject`, `pdffile`, `description`) VALUES(?)";
    console.log(req.body);
    console.log(req.file);
    const values =[
        req.body.bookname,
        req.body.booktitle,
        req.body.class,
        req.body.subject,
        req.file.filename,
        req.body.description       
    ];
    // const image = ;
    db.query(sql,[values],(err,result)=>{
        // if(req.files.uploadfilefile){
            console.log(req.file, req.body)
        // }
        if(err) return res.json(err);
        return res.json(result);   
    })
})




app.post("/login",(req,res)=>{
const username = req.body.username;
const password = req.body.password;
const sql = "SELECT * FROM `admin` WHERE username =? AND password = ?";
// res.sendFile(__dirname +"/books");
db.query(sql,[username,password],(err,result)=>{
    if(err) return res.send({Message : "Error in Authentication database"});
    // res.sendFile("books");
    // authFunction(true);
    return res.send(result);
})
   
})

const appPort = 8081;
app.listen(process.env.PORT || appPort,()=>{
    console.log("listening");
})